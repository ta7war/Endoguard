﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace EndoGuard
{
    public class ForensicDataCollector
    {
        public List<string> CollectEventLogs()
        {
            List<string> eventLogs = new List<string>();

            // Define the log names we want to collect
            string[] logNames = { "Security", "System", "Application" };

            foreach (string logName in logNames)
            {
                try
                {
                    EventLog eventLog = new EventLog(logName);

                    foreach (EventLogEntry entry in eventLog.Entries)
                    {
                        // Filtering only recent events
                        if (entry.TimeGenerated >= DateTime.Now.AddDays(-1)) // last 24 hours
                        {
                            string logEntry = $"{entry.TimeGenerated}: {entry.EntryType} - {entry.Source} - {entry.Message}";
                            eventLogs.Add(logEntry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    eventLogs.Add($"Error reading {logName} logs: {ex.Message}");
                }
            }

            return eventLogs;
        }

        public List<string> CollectNetworkActivity()
        {
            List<string> networkConnections = new List<string>();

            try
            {
                Process netstatProcess = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "netstat",
                        Arguments = "-an",
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };

                netstatProcess.Start();
                string output = netstatProcess.StandardOutput.ReadToEnd();
                netstatProcess.WaitForExit();

                // Split output by line and add to list
                var lines = output.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                networkConnections.AddRange(lines);
            }
            catch (Exception ex)
            {
                networkConnections.Add($"Error retrieving network activity: {ex.Message}");
            }

            return networkConnections;
        }
    }
}