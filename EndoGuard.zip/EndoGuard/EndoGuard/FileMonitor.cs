﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Controls;

namespace EndoGuard
{
    public class FileMonitor
    {
        private readonly FileSystemWatcher _fileSystemWatcher;
        private readonly List<string> _fileChanges;
        private readonly ListBox _activityLog;
        private readonly DatabaseHelper _databaseHelper;

        public FileMonitor(ListBox activityLog, DatabaseHelper databaseHelper)
        {
            _fileChanges = new List<string>();
            _activityLog = activityLog;
            _databaseHelper = databaseHelper;

            _fileSystemWatcher = new FileSystemWatcher
            {
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.DirectoryName
            };

            _fileSystemWatcher.Changed += OnChanged;
            _fileSystemWatcher.Renamed += OnRenamed;
        }

        public void StartMonitoring(string path)
        {
            _fileSystemWatcher.Path = path;
            _fileSystemWatcher.EnableRaisingEvents = true;

            // Check existing files in the directory and log them
            var files = Directory.GetFiles(path);
            foreach (var file in files)
            {
                // Check if the file is hidden
                var fileInfo = new FileInfo(file);
                if (fileInfo.Attributes.HasFlag(FileAttributes.Hidden))
                {
                    string message = $"Hidden file found: {file}";
                    _fileChanges.Add(message);
                    AddToActivityLog(message);
                }
                else
                {
                    string message = $"Found file: {file}";
                    _fileChanges.Add(message);
                    AddToActivityLog(message);
                }
            }
        }

        public void StopMonitoring()
        {
            _fileSystemWatcher.EnableRaisingEvents = false;
        }

        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            string message = $"{e.ChangeType}: {e.FullPath}";
            _fileChanges.Add(message);
            AddToActivityLog(message);

            // Log network activity
            _databaseHelper.InsertNetworkActivity(e.ChangeType.ToString(), e.FullPath);
        }

        private void OnRenamed(object sender, RenamedEventArgs e)
        {
            string message = $"Renamed: {e.OldFullPath} to {e.FullPath}";
            _fileChanges.Add(message);
            AddToActivityLog(message);

            // Log network activity
            _databaseHelper.InsertNetworkActivity("Renamed", $"{e.OldFullPath} to {e.FullPath}");
        }

        private void AddToActivityLog(string message)
        {
            if (_activityLog.Dispatcher.CheckAccess())
            {
                _activityLog.Items.Add(message);
            }
            else
            {
                _activityLog.Dispatcher.Invoke(() => _activityLog.Items.Add(message));
            }
        }
    }
}
