﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace EndoGuard
{
    public partial class MainWindow : Window
    {
        private FileMonitor _fileMonitor;
        private DatabaseHelper _databaseHelper;
        private readonly ForensicDataCollector _forensicDataCollector = new ForensicDataCollector();
        private readonly NetworkMonitor _networkMonitor;

        public MainWindow()
        {
            InitializeComponent();
            _databaseHelper = new DatabaseHelper();
            _fileMonitor = new FileMonitor(ActivityLog, _databaseHelper);
            _networkMonitor = new NetworkMonitor(_databaseHelper);

            // Remove hardcoded IOC and insert initial sample IOCs, if necessary
            // Uncomment to use sample data or modify as needed
            // _databaseHelper.InsertIOC("Filename", "suspicious_file.exe");
            _ = _networkMonitor.MonitorConnectionsAsync();
        }

        private void StartMonitoring_Click(object sender, RoutedEventArgs e)
        {
            string directoryPath = DirectoryTextBox.Text;
            if (Directory.Exists(directoryPath))
            {
                _fileMonitor.StartMonitoring(directoryPath);
            }
            else
            {
                MessageBox.Show("Please enter a valid directory.", "Invalid Directory", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void StopMonitoring_Click(object sender, RoutedEventArgs e)
        {
            _fileMonitor.StopMonitoring();
        }

        private void AddIocButton_Click(object sender, RoutedEventArgs e)
        {
            if (IocTypeComboBox.SelectedItem is ComboBoxItem selectedItem &&
                !string.IsNullOrWhiteSpace(IocValueTextBox.Text))
            {
                string iocType = selectedItem.Content?.ToString(); // Safe navigation
                string iocValue = IocValueTextBox.Text;

                if (!string.IsNullOrEmpty(iocType)) // Check for null or empty
                {
                    // Insert IOC into the database
                    _databaseHelper.InsertIOC(iocType, iocValue);
                    MessageBox.Show("IOC added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Clear inputs
                    IocTypeComboBox.SelectedIndex = -1;
                    IocValueTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Invalid IOC type.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a type and enter a value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ViewIocsButton_Click(object sender, RoutedEventArgs e)
        {
            IoCListBox.Items.Clear();
            var iocs = _databaseHelper.GetAllIOCs(); // Fetch all IOCs from the database
            foreach (var (type, value) in iocs)
            {
                IoCListBox.Items.Add($"{type}: {value}");
            }
        }

        private void DeleteIocButton_Click(object sender, RoutedEventArgs e)
        {
            if (IoCListBox.SelectedItem is string selectedIoc)
            {
                // Parse IOC Type and Value from selected item
                var parts = selectedIoc.Split(new[] { ": " }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 2)
                {
                    string iocType = parts[0];
                    string iocValue = parts[1];
                    _databaseHelper.DeleteIOC(iocType, iocValue);
                    MessageBox.Show("IOC deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    ViewIocsButton_Click(sender, e);  // Refresh the IOC list
                }
            }
            else
            {
                MessageBox.Show("Please select an IOC to delete.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CollectEventLogsButton_Click(object sender, RoutedEventArgs e)
        {
            EventLogsListBox.Items.Clear();
            var eventLogs = _forensicDataCollector.CollectEventLogs();
            foreach (var log in eventLogs)
            {
                EventLogsListBox.Items.Add(log);
            }
        }

        private void CollectNetworkActivityButton_Click(object sender, RoutedEventArgs e)
        {
            NetworkActivityListBox.Items.Clear();
            var networkConnections = _forensicDataCollector.CollectNetworkActivity();
            foreach (var connection in networkConnections)
            {
                NetworkActivityListBox.Items.Add(connection);
            }
        }

        private void BrowseDirectory_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Select a Directory",
                Filter = "All Files (*.*)|*.*",
                FileName = "Select a file" // Just a placeholder since we want a directory
            };

            if (dialog.ShowDialog() == true)
            {
                DirectoryTextBox.Text = Path.GetDirectoryName(dialog.FileName); // Get the directory from the selected file
            }
        }

        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            var reportContent = new StringBuilder();
            reportContent.AppendLine("EndoGuard Monitoring Report");
            reportContent.AppendLine($"Report Date: {DateTime.Now}");
            reportContent.AppendLine();
            reportContent.AppendLine("Monitored File Activities:");
            foreach (var item in ActivityLog.Items)
            {
                reportContent.AppendLine(item.ToString());
            }
            reportContent.AppendLine();
            reportContent.AppendLine("Event Logs Collected:");
            foreach (var log in EventLogsListBox.Items)
            {
                reportContent.AppendLine(log.ToString());
            }
            reportContent.AppendLine();
            reportContent.AppendLine("Network Activity Collected:");
            foreach (var connection in NetworkActivityListBox.Items)
            {
                reportContent.AppendLine(connection.ToString());
            }

            // Save the report as a .txt file
            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "EndoGuard_Report.txt");
            File.WriteAllText(filePath, reportContent.ToString());
            MessageBox.Show($"Report generated at {filePath}", "Report Generated", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null)
            {
                textBox.Clear();
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Enter directory path..."; // Placeholder text
            }
        }
    }
}
