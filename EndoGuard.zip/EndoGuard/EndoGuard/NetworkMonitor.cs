﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace EndoGuard
{
    public class NetworkMonitor
    {
        private bool _isMonitoring;
        private readonly DatabaseHelper _databaseHelper;

        public NetworkMonitor(DatabaseHelper databaseHelper)
        {
            _databaseHelper = databaseHelper;
        }

        public async Task MonitorConnectionsAsync()
        {
            _isMonitoring = true;
            while (_isMonitoring)
            {
                var connections = GetActiveConnections();

                foreach (var connection in connections)
                {
                    // Store each connection in the database with a placeholder for filePath
                    // Adjust this according to your application logic
                    _databaseHelper.InsertNetworkActivity("Active Connection", connection); // Assuming connection is the filePath or details needed
                }

                await Task.Delay(5000); // Wait 5 seconds between checks
            }
        }

        public void StopMonitoring()
        {
            _isMonitoring = false;
        }

        private List<string> GetActiveConnections()
        {
            List<string> activeConnections = new List<string>();

            try
            {
                using (Process netstatProcess = new Process())
                {
                    netstatProcess.StartInfo.FileName = "netstat";
                    netstatProcess.StartInfo.Arguments = "-an"; // Shows all connections and listening ports
                    netstatProcess.StartInfo.UseShellExecute = false;
                    netstatProcess.StartInfo.RedirectStandardOutput = true;
                    netstatProcess.StartInfo.CreateNoWindow = true;

                    netstatProcess.Start();

                    while (!netstatProcess.StandardOutput.EndOfStream)
                    {
                        string line = netstatProcess.StandardOutput.ReadLine();
                        if (!string.IsNullOrWhiteSpace(line) && line.Contains("TCP"))
                        {
                            activeConnections.Add(line.Trim());
                        }
                    }

                    netstatProcess.WaitForExit();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error while retrieving network connections: {ex.Message}");
            }

            return activeConnections;
        }
    }
}