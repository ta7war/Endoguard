﻿using System.Collections.Generic;
using System.Data.SQLite;

namespace EndoGuard
{
    public class DatabaseHelper
    {
        private readonly string _connectionString;

        public DatabaseHelper()
        {
            _connectionString = "Data Source=EndoGuard.db;Version=3;";
            CreateDatabase();
        }

        private void CreateDatabase()
        {
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            var command = connection.CreateCommand();

            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS IOCs (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Type TEXT NOT NULL,
                    Value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS NetworkActivities (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ActivityType TEXT NOT NULL,
                    FilePath TEXT NOT NULL
                );
            ";

            command.ExecuteNonQuery();
        }

        public void ClearIOCs() // New method to clear all IOCs
        {
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM IOCs"; // Delete all entries
            command.ExecuteNonQuery();
        }

        public void InsertIOC(string type, string value)
        {
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "INSERT INTO IOCs (Type, Value) VALUES (@type, @value)";
            command.Parameters.AddWithValue("@type", type);
            command.Parameters.AddWithValue("@value", value);
            command.ExecuteNonQuery();
        }

        public void InsertNetworkActivity(string activityType, string filePath)
        {
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "INSERT INTO NetworkActivities (ActivityType, FilePath) VALUES (@activityType, @filePath)";
            command.Parameters.AddWithValue("@activityType", activityType);
            command.Parameters.AddWithValue("@filePath", filePath);
            command.ExecuteNonQuery();
        }

        public void DeleteIOC(string type, string value)
        {
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM IOCs WHERE Type = @type AND Value = @value";
            command.Parameters.AddWithValue("@type", type);
            command.Parameters.AddWithValue("@value", value);
            command.ExecuteNonQuery();
        }

        public List<(string Type, string Value)> GetAllIOCs()
        {
            var iocs = new List<(string Type, string Value)>();
            using var connection = new SQLiteConnection(_connectionString);
            connection.Open();
            using var command = new SQLiteCommand("SELECT Type, Value FROM IOCs", connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                iocs.Add((reader.GetString(0), reader.GetString(1)));
            }
            return iocs;
        }
    }
}